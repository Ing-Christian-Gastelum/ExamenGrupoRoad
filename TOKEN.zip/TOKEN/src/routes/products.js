const express = require('express');
const router = express.Router();
const {API}=require('../keys')

const fetch = require("node-fetch");


router.post('/product', async (req, res)=>{
    const {product}=req.body
    const resultProduct = await getProduct(product)
    res.json(resultProduct)

})


async function getProduct(id) {
var url =API.host + "products/"+id;
const resProducts = await fetch(url, {
        method: 'get', 
        headers:{
          'x-access-token': '123'
        }})
const products = await resProducts.json();
return products
}


module.exports = router;
