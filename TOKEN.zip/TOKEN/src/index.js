const express = require('express');
const path = require('path');
const morgan = require('morgan');
const colors = require('colors/safe');

//initializations
const app = express();

//setting
app.set('port', process.env.PORT || 4000);
app.set('views', path.join(__dirname, 'public'));

//Middlewares
app.use(morgan('dev'));
app.use(express.urlencoded({extended: false}));
app.use(express.json());

//Global Variables
app.use((req, res, next)=> {
    next();
});

//Routers
app.use(require('./routes'));
app.use(require('./routes/products'));

//public
app.use(express.static(path.join(__dirname, 'public')));


//Starting the server

app.listen(app.get('port'), () => {

    console.log(colors.green('Server on port: '), app.get('port'));
});

