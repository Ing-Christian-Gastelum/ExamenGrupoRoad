$(function () {
  
  $('#formSearch').on('submit', function(e){
    e.preventDefault();
    let product = $('#searchProduct');    
    $.ajax({
      url:'/product',
      method: 'POST',
      data:{
        product:product.val(),
      },
      success: function(resultProduct){
        let tbody = $('#result');
        tbody.html('');
       resultProduct.forEach(product =>{
        tbody.append(`
        <tr>
        <td>${product.id_code}</td>
        <td>${product.SKU}</td>
        <td>${product.descrip}</td>
      </tr>
        `)
      })
      }

    });



  });


 
 


})