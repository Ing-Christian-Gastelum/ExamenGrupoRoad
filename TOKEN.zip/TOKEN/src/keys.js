module.exports = {
    //database
    API: {
        host: 'http://localhost:3000/api/',
        },
        
     Token:{
        token:"123"
     }
}; 