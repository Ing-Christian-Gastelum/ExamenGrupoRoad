module.exports = {
    //database
    database: {
        host: 'localhost',
        user: 'root',
        password: 'N0d3JS123',
        database: 'warehouse'
    }
}; 