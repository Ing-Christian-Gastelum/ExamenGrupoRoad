function verifyToken(req, res, next) {
    const token = req.headers['x-access-token'];
    if(!token){
        return res.status(401).json({
            access:false,
            message:"No Tienes un Token"
        });
    }else if(token!='123'){
        return res.status(401).json({
            access:false,
            message:"Token Incorrecto"
        });
    }
    next();
}
module.exports = verifyToken;