const express = require("express");
const router = express.Router();
const verifyToken = require('../controller/verifyToken')
const {DB} = require("../database");

//GET WAREHOUSE
router.get("/products/:id",verifyToken, (req, res, next) => {
  const {id} = req.params;
  const query ='SELECT * FROM warehouse.products where id_code="'+id+'" || SKU ="'+id+'" ;'
  DB.query(query,
    (err, rows, fields) => {
      if (!err) {
        res.status(200).json(rows);
      } else {
        res.status(401).json({message:'No exixte'});
      }
    }
  );
})

module.exports = router;
